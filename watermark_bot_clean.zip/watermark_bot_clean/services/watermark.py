# watermark logic

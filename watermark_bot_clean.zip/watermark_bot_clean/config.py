# config.py - your config
TOKEN = 'YOUR_TOKEN'

# bot.py - main entry

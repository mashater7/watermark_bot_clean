# common.py - shared logic

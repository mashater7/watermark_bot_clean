# single photo handler
